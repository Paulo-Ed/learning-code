package capitulo_02;

public class Questao8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\t\"Bem vindo\"");
		System.out.println("\t\"tao\"");
		System.out.println("\t\"Java\"");
		System.out.println("\t\"Programing!\"");
	}

}
