package capitulo_02;

public class Questao5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Bem-vindo Paulo 201916-RC0311! Sauda��es!\n");
	}

}
