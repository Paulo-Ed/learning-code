package capitulo_02;

public class Questao7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("\tBem vindo");
		System.out.println("\tao");
		System.out.println("\tJava");
		System.out.println("\tPrograming!");
	}

}
