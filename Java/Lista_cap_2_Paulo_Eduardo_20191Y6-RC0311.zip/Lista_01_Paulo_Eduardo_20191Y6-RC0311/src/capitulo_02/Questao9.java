package capitulo_02;

public class Questao9 {

	static String nome = "Paulo", matricula = "201916-RC0311", data_hora = "15/03/2021 11:00", mensagem = "Seja Bem Vindo";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf(nome);
		System.out.printf(matricula);
		System.out.printf(data_hora);
		System.out.printf(mensagem);

	}

}
