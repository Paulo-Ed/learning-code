package cap�tulo_03;
import javax.swing.JOptionPane;
public class Dialog1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Ol� Mundo");
	}

}
