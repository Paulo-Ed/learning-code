package capitulo_02;

public class Questao4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			// TODO Auto-generated method stub
			//System.out.println("Bem vindo ao Java Programing!");
			System.out.println("Bem-vindo");
			System.out.println("Paulo 201916-RC0311");
			System.out.println("! Sauda��es!");
			System.out.println("\n");
	}
}
