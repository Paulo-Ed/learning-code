package capitulo_02;

public class Questao6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Bem-vindo\nPaulo\n201916-RC0311!\nSauda��es!\n");
	}

}
